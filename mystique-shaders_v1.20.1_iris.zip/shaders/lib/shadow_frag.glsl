#ifndef SHADOW_FRAG_GLSL
#define SHADOW_FRAG_GLSL
#include "/lib/settings.glsl"

uniform sampler2D shadowtex1;     // opaque-only depth, so water/glass do not cast

// 1.0 = lit, 0.0 = shadowed.  Cheap early-outs keep it fast on phones.
float shadowFor(vec3 sc, float dist, float ndl) {
    float fade = smoothstep(shadowDistance * 0.75, shadowDistance * 0.98, dist);
    if (ndl <= 0.0 || fade >= 1.0) return 1.0;
    if (sc.x < 0.0 || sc.y < 0.0 || sc.x > 1.0 || sc.y > 1.0) return 1.0;

    float z = sc.z - (0.0007 + 0.0012 * (1.0 - ndl));
#if SHADOW_SOFT == 0
    float s = step(z, textureLod(shadowtex1, sc.xy, 0.0).r);
#else
    float o = 1.1 / float(shadowMapResolution);
    float s = step(z, textureLod(shadowtex1, sc.xy + vec2( o,  o), 0.0).r)
            + step(z, textureLod(shadowtex1, sc.xy + vec2(-o,  o), 0.0).r)
            + step(z, textureLod(shadowtex1, sc.xy + vec2( o, -o), 0.0).r)
            + step(z, textureLod(shadowtex1, sc.xy + vec2(-o, -o), 0.0).r);
    s *= 0.25;
#endif
    return mix(s, 1.0, fade);
}
#endif
