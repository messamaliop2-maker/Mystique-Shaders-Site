#ifndef SHADOW_VERT_GLSL
#define SHADOW_VERT_GLSL
#include "/lib/shadow.glsl"

uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

// relPos = camera-relative world position, nW = world-space normal
vec3 getShadowCoord(vec3 relPos, vec3 nW) {
    float dist = length(relPos);
    vec3 p = relPos + nW * (0.05 + 0.0025 * dist);          // normal offset against acne
    vec4 sp = shadowProjection * (shadowModelView * vec4(p, 1.0));
    sp.xy = distortShadow(sp.xy);
    return sp.xyz * 0.5 + 0.5;
}
#endif
