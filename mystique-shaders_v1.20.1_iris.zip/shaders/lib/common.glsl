#ifndef COMMON_GLSL
#define COMMON_GLSL
#include "/lib/settings.glsl"

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform mat4 gbufferModelViewInverse;

// ---------------------------------------------------------------- time of day
struct Tod {
    float day;
    float night;
    float sunset;
    float rain;
    float sunH;
};

Tod getTod() {
    Tod t;
    t.sunH   = dot(normalize(sunPosition), normalize(upPosition));
    t.day    = smoothstep(0.10, 0.45, t.sunH);
    t.night  = 1.0 - smoothstep(-0.22, 0.05, t.sunH);
    t.sunset = clamp(1.0 - t.day - t.night, 0.0, 1.0);
    t.rain   = rainStrength;
    return t;
}
vec4 todVec(Tod t) { return vec4(t.day, t.night, t.sunset, t.rain); }
Tod makeTod(vec4 v) { Tod t; t.day = v.x; t.night = v.y; t.sunset = v.z; t.rain = v.w; t.sunH = 0.0; return t; }

vec3 sunDirW()  { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }
vec3 moonDirW() { return normalize(mat3(gbufferModelViewInverse) * moonPosition); }

// ---------------------------------------------------------------- noise
float hs(float n) { return fract(sin(n) * 43758.5453); }
float ns(vec2 x) {
    vec2 p = floor(x);
    vec2 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    float n = p.x + p.y * 57.0;
    return mix(mix(hs(n), hs(n + 1.0), f.x), mix(hs(n + 57.0), hs(n + 58.0), f.x), f.y);
}

// ---------------------------------------------------------------- tonemapping (original filmic curve)
float filmic(float x) {
    return ((x * (4.0 * x + 0.33) + 0.032) / (x * (4.0 * x + 1.1) + 0.84)) - 0.0380952;
}
vec3 filmicRGB(vec3 c) {
    return vec3(filmic(c.r), filmic(c.g), filmic(c.b)) * 1.2641257;   // / filmic(1.5)
}
vec3 toneMapBun(vec3 c) {
    c *= mix(vec3(1.0), vec3(1.9, 1.1, 1.0), WARMTH);                 // original crimson grade
    return filmicRGB(c);
}
vec3 saturation(vec3 rgb, float adj) {
    float i = dot(rgb, vec3(0.2125, 0.7154, 0.0721));
    return mix(vec3(i), rgb, adj);
}

// ---------------------------------------------------------------- sky
vec3 rainGrey(Tod t) {
    return mix(vec3(0.58, 0.60, 0.63), vec3(0.04, 0.05, 0.07), t.night) * mix(1.0, 0.7, t.sunset);
}

// horizon colour only (cheap; used for fog so it matches the sky at the horizon)
vec3 fogGradient(vec3 d, Tod t, vec3 sd) {
    vec3 hor = vec3(0.86, 0.82, 0.74) * t.day + vec3(0.08, 0.14, 0.30) * t.night;
    if (t.sunset > 0.001) {
        float az = max(dot(normalize(d.xz + 1e-4), normalize(sd.xz + 1e-4)), 0.0);
        hor += mix(vec3(0.62, 0.30, 0.38), vec3(1.15, 0.32, 0.08), az * az * sqrt(az)) * t.sunset;
        float sg = max(dot(d, sd), 0.0);
        float sg2 = sg * sg; sg2 *= sg2; sg2 *= sg2;                  // ^16
        hor += vec3(1.3, 0.55, 0.18) * (sg2 * sg2 * 0.8 * t.sunset * (1.0 - t.rain));
    }
    return mix(hor, rainGrey(t), t.rain);
}

vec3 skyGradient(vec3 d, Tod t, vec3 sd, vec3 md) {
    vec3 zen = vec3(0.12, 0.50, 0.78) * t.day
             + vec3(0.22, 0.24, 0.50) * t.sunset
             + vec3(0.02, 0.05, 0.16) * t.night;
    vec3 hor = vec3(0.86, 0.82, 0.74) * t.day + vec3(0.08, 0.14, 0.30) * t.night;
    if (t.sunset > 0.001) {
        float az = max(dot(normalize(d.xz + 1e-4), normalize(sd.xz + 1e-4)), 0.0);
        hor += mix(vec3(0.62, 0.30, 0.38), vec3(1.15, 0.32, 0.08), az * az * sqrt(az)) * t.sunset;
    }
    vec3 rg = rainGrey(t);
    zen = mix(zen, rg * 0.85, t.rain);
    hor = mix(hor, rg, t.rain);

    float y = max(d.y, 0.0);
    float iy = 1.0 - y;
    float k = iy * iy * iy;
    k = mix(k * iy, k, t.sunset);
    vec3 c = mix(zen, hor, k);

    float dry = 1.0 - t.rain;
    float sg = max(dot(d, sd), 0.0);
    if (t.sunset > 0.001) {
        float s2 = sg * sg; s2 *= s2; s2 *= s2;                       // ^16
        c += vec3(1.3, 0.55, 0.18) * (s2 * s2 * 0.8 * t.sunset * dry);
    }
    if (t.day > 0.001) {
        c += vec3(0.9, 0.75, 0.5) * (pow(sg, 64.0) * 0.35 * t.day * dry);
    }
    if (t.night > 0.001) {
        float mg = max(dot(d, md), 0.0);
        float m2 = mg * mg; m2 *= m2; m2 *= m2;                       // ^8
        c += vec3(0.10, 0.15, 0.30) * (m2 * 0.35 * t.night * dry);
    }
    return c;
}

// ---------------------------------------------------------------- world lighting environment
// Everything that only depends on time of day is computed once per vertex and passed as flat
// varyings, so the fragment shader does no per-pixel time-of-day math.
#define ENV_OUT flat out vec3 envAmb; flat out vec3 envDir; flat out vec3 envL; flat out vec3 envUp; flat out vec3 envTw;
#define ENV_IN  flat in  vec3 envAmb; flat in  vec3 envDir; flat in  vec3 envL; flat in  vec3 envUp; flat in  vec3 envTw;
#define ENV_CALC calcEnv(envAmb, envDir, envL, envUp, envTw);
#define SHADE(a, lm, n, sh) shadeScene(a, lm, n, sh, envAmb, envDir, envL, envUp, envTw)

void calcEnv(out vec3 amb, out vec3 dcol, out vec3 L, out vec3 up, out vec3 tw) {
    Tod t = getTod();
    vec3 sdv = normalize(sunPosition);
    vec3 mdv = normalize(moonPosition);

#ifdef SHADOWS
    vec3 ambDay = vec3(0.58, 0.68, 0.80);
    vec3 dirDay = vec3(0.74, 0.63, 0.46);
#else
    vec3 ambDay = vec3(0.68, 0.77, 0.85);
    vec3 dirDay = vec3(0.55, 0.47, 0.34);
#endif
    amb = ambDay * t.day + vec3(0.34, 0.36, 0.52) * t.sunset + vec3(0.13, 0.18, 0.28) * t.night;
    vec3 ambR = mix(vec3(0.40, 0.42, 0.45), vec3(0.13, 0.18, 0.28), t.night);
    amb = mix(amb, ambR, t.rain);

    // crimson sun light fades out as the sun sets (shadow light flips to the moon at the horizon)
    float setFade = smoothstep(-0.10, 0.02, t.sunH);
    dcol = dirDay * t.day + vec3(1.28, 0.40, 0.10) * (t.sunset * setFade) + vec3(0.04, 0.055, 0.105) * t.night;
    L = (t.sunH > 0.0) ? sdv : mdv;
    up = normalize(upPosition);
    tw = vec3(t.night, t.rain, t.sunset);
}

// lmIn = raw vanilla lightmap coords (x = block, y = sky), N = view-space normal, shadow: 1 = lit
vec3 shadeScene(vec3 albedo, vec2 lmIn, vec3 N, float shadow,
                vec3 ambC, vec3 dirCol, vec3 L, vec3 up, vec3 tw) {
    vec2 lm = clamp((lmIn - 0.0313) / 0.9375, 0.0, 1.0);
    float skyL = lm.y * lm.y * (3.0 - 2.0 * lm.y);
    float hemi = mix(0.72, 1.0, dot(N, up) * 0.5 + 0.5);
    vec3 ambient = mix(vec3(0.050, 0.055, 0.070), ambC * hemi, skyL);

    float ndl = max(dot(N, L), 0.0);
    float dmask = smoothstep(0.78, 0.95, lm.y) * (1.0 - tw.y);
    vec3 direct = dirCol * (ndl * dmask * shadow);

    // warm block light, strongest at night / in caves (as in the original)
    float torchAmt = clamp(tw.x * lm.y + (1.0 - lm.y) + 0.25 * tw.z * lm.y + 0.3 * tw.y * lm.y, 0.0, 1.0);
    float x = lm.x, x2 = x * x, x4 = x2 * x2;
    float bl = x2 * sqrt(x);                      // ~ x^2.5
    float g  = x4 * x4;                           // x^8
    vec3 col = albedo * (ambient + direct + vec3(1.6, 0.68, 0.20) * (bl * torchAmt))
             + vec3(1.2, 0.7, 0.1) * (g * torchAmt * 0.45);

    col = toneMapBun(col);
    if (tw.y > 0.001) col = saturation(col, 1.0 - 0.6 * tw.y);
    return col;
}
#endif
