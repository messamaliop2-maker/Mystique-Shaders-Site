#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

// ---- Shadows -------------------------------------------------------------
#define SHADOWS
#define SHADOW_SOFT 1                              //[0 1]
const int shadowMapResolution = 1024;              //[512 768 1024 1536 2048 3072]
const float shadowDistance = 48.0;                 //[24.0 32.0 48.0 64.0 96.0 128.0]
const float sunPathRotation = 25.0;                //[0.0 10.0 20.0 25.0 30.0 40.0]

// ---- Look ----------------------------------------------------------------
#define WARMTH 0.60                                //[0.00 0.20 0.40 0.60 0.80 1.00]
#define STAR_BRIGHTNESS 1.0                        //[0.5 1.0 1.5 2.0]

// ---- Motion --------------------------------------------------------------
#define WAVING_FOLIAGE
#define WAVING_WATER
#define WAVE_STRENGTH 1.0                          //[0.5 1.0 1.5 2.0]

// ---- Water ---------------------------------------------------------------
#define WATER_QUALITY 1                            //[0 1 2]
#define WATER_REFLECT 0.70                         //[0.00 0.30 0.50 0.70 0.90]

// ---- Atmosphere ----------------------------------------------------------
#define FOG_AMOUNT 1.0                             //[0.0 0.5 1.0 1.5 2.0]
#define UNDERWATER_WOBBLE

#endif
