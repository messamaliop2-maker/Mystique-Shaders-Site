#ifndef SHADOW_GLSL
#define SHADOW_GLSL
#include "/lib/settings.glsl"

// Pushes shadow-map resolution towards the player. Must be identical in the
// shadow pass and when sampling.
vec2 distortShadow(vec2 p) {
    float f = length(p) * 0.85 + 0.15;
    return p / f;
}
#endif
