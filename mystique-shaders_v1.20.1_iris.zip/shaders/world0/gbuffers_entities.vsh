#version 330 compatibility
#include "/lib/common.glsl"
#ifdef SHADOWS
#include "/lib/shadow_vert.glsl"
#endif

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normalV;
ENV_OUT
#ifdef SHADOWS
out vec3 shadowCoord;
out float viewDist;
#endif

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);
    ENV_CALC
#ifdef SHADOWS
    vec3 rel = (gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
    viewDist = length(rel);
    shadowCoord = getShadowCoord(rel, mat3(gbufferModelViewInverse) * normalV);
#endif
    gl_Position = ftransform();
}
