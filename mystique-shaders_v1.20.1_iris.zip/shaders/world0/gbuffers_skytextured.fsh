#version 330 compatibility
#include "/lib/common.glsl"

uniform sampler2D gtexture;
uniform int renderStage;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */

void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (renderStage == MC_RENDER_STAGE_SUN) {
        Tod t = getTod();
        c.rgb *= mix(vec3(1.15, 1.0, 0.85), vec3(1.7, 0.55, 0.22), t.sunset);   // red-orange sun at dusk/dawn
        c.rgb *= 1.0 - 0.6 * t.rain;
    } else if (renderStage == MC_RENDER_STAGE_MOON) {
        c.rgb *= vec3(0.85, 0.95, 1.2) * (1.0 - 0.6 * getTod().rain);
    }
    gl_FragData[0] = c;
}
