#version 330 compatibility
#include "/lib/common.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normalV;
ENV_IN

/* RENDERTARGETS: 0 */

void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (c.a < 0.1) discard;
    gl_FragData[0] = vec4(SHADE(c.rgb, lmcoord, normalize(normalV), 1.0), c.a);
}
