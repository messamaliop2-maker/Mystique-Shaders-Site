#version 330 compatibility
#include "/lib/common.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;
in vec3 wpos;

/* RENDERTARGETS: 0 */

void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (c.a < 0.01) discard;
    Tod t = getTod();
    vec2 p = wpos.xz * 0.025 + frameTimeCounter * 0.01;
    float n = ns(p) * 0.65 + ns(p * 2.3 + 7.1) * 0.35;
    vec3 tint = mix(vec3(1.0), vec3(1.40, 0.62, 0.42), t.sunset * (1.0 - t.rain));   // crimson sunset clouds
    c.rgb *= tint * (0.85 + 0.30 * n);
    gl_FragData[0] = c;
}
