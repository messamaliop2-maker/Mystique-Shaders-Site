#version 330 compatibility
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform float far;
uniform int isEyeInWater;

in vec2 texcoord;
flat in vec4 todV;
flat in vec3 sunW;

/* RENDERTARGETS: 0 */

void main() {
    vec2 uv = texcoord;
#ifdef UNDERWATER_WOBBLE
    if (isEyeInWater == 1) {
        uv += vec2(sin(uv.y * 18.0 + frameTimeCounter * 1.8),
                   cos(uv.x * 14.0 + frameTimeCounter * 1.6)) * 0.0035;
    }
#endif

    vec3 col = texture(colortex0, uv).rgb;
    float depth = texture(depthtex0, uv).r;
    Tod t = makeTod(todV);

    if (isEyeInWater == 0) {
        if (FOG_AMOUNT > 0.0 && depth < 1.0) {
            vec4 vp = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
            vp.xyz /= vp.w;
            float dist = length(vp.xyz);
            float fs = far * 0.55 * mix(1.0, 0.35, t.rain);
            float f = smoothstep(fs, far, dist) * 0.95
                    + (1.0 - exp(-dist * 0.001 * (1.0 + 3.0 * t.rain))) * 0.55;
            f = clamp(f * FOG_AMOUNT, 0.0, 1.0);
            if (f > 0.002) {
                vec3 dirW = mat3(gbufferModelViewInverse) * (vp.xyz / dist);
                vec3 fogDir = normalize(vec3(dirW.x, max(dirW.y * 0.15, 0.0), dirW.z));
                col = mix(col, filmicRGB(fogGradient(fogDir, t, sunW)), f);
            }
        }
    } else {
        vec4 vp = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
        float dist = length(vp.xyz / vp.w);
        if (isEyeInWater == 1) {
            float l = t.day + 0.6 * t.sunset + 0.25 * t.night;
            vec3 wc = vec3(0.03, 0.30, 0.42) * (0.35 + 0.65 * l);
            col = mix(col * vec3(0.75, 0.95, 1.0), wc, 1.0 - exp(-dist * 0.075));
        } else if (isEyeInWater == 2) {
            col = mix(col, vec3(1.0, 0.35, 0.05), 1.0 - exp(-dist * 0.8));
        } else {
            col = mix(col, vec3(0.9, 0.95, 1.0), 1.0 - exp(-dist * 1.2));   // powder snow
        }
    }

    gl_FragData[0] = vec4(col, 1.0);
}
