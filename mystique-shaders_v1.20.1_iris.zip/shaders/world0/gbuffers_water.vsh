#version 330 compatibility
#include "/lib/common.glsl"

uniform vec3 cameraPosition;
uniform mat4 gbufferModelView;

in vec4 mc_Entity;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normalV;
out vec3 normalW;
out vec3 worldPos;
out vec3 relPos;
flat out int isWater;
flat out vec4 todV;
flat out vec3 sunW;
flat out vec3 moonW;
ENV_OUT

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);
    normalW  = mat3(gbufferModelViewInverse) * normalV;
    int water = (int(mc_Entity.x + 0.5) == 10010) ? 1 : 0;
    isWater  = water;
    todV  = todVec(getTod());
    sunW  = sunDirW();
    moonW = moonDirW();
    ENV_CALC

    vec4 pos = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);

#ifdef WAVING_WATER
    if (water == 1) {
        vec3 wp = pos.xyz + cameraPosition;
        float sky = smoothstep(0.2, 0.9, lmcoord.y);
        float w = sin(frameTimeCounter * 2.2 + wp.x * 1.3 + wp.z * 1.7 + wp.y) * sin(wp.z * 0.9 + frameTimeCounter * 0.7);
        pos.y += (w * 0.045 * WAVE_STRENGTH - 0.03) * sky;
    }
#endif

    worldPos = pos.xyz + cameraPosition;
    relPos   = pos.xyz;
    gl_Position = gl_ProjectionMatrix * (gbufferModelView * pos);
}
