#version 330 compatibility
#include "/lib/common.glsl"
#ifdef SHADOWS
#include "/lib/shadow_vert.glsl"
#endif

uniform vec3 cameraPosition;
uniform mat4 gbufferModelView;

in vec4 mc_Entity;
in vec4 mc_midTexCoord;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normalV;
ENV_OUT
#ifdef SHADOWS
out vec3 shadowCoord;
out float viewDist;
#endif

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);
    ENV_CALC

    vec4 pos = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);

#ifdef WAVING_FOLIAGE
    int id = int(mc_Entity.x + 0.5);
    if (id == 10001 || id == 10002) {
        vec3 wp = pos.xyz + cameraPosition;
        float tm = frameTimeCounter;
        float sky = smoothstep(0.2, 0.9, lmcoord.y);          // no wind in caves (original: * uv1.y)
        float w = 0.6;                                        // leaves: whole block shimmers
        if (id == 10002) w = (gl_MultiTexCoord0.t < mc_midTexCoord.t) ? 1.0 : 0.0;   // plants: top sways
        float a = sin(wp.y * 2.0 + wp.z + cos(tm * 1.5 + wp.x)) * 0.055;
        float b = sin(wp.y * 1.7 + wp.x * 0.8 + cos(tm * 1.3 + wp.z)) * 0.035;
        pos.x += a * w * sky * WAVE_STRENGTH;
        pos.z += b * w * sky * WAVE_STRENGTH;
    }
#endif

#ifdef SHADOWS
    viewDist = length(pos.xyz);
    shadowCoord = getShadowCoord(pos.xyz, mat3(gbufferModelViewInverse) * normalV);
#endif

    gl_Position = gl_ProjectionMatrix * (gbufferModelView * pos);
}
