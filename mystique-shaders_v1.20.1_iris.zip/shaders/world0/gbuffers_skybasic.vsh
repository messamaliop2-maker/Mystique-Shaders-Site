#version 330 compatibility
#include "/lib/common.glsl"

out vec4 glcolor;
out vec3 starPos;
flat out vec4 todV;
flat out vec3 sunW;
flat out vec3 moonW;

void main() {
    glcolor = gl_Color;
    starPos = gl_Vertex.xyz;
    todV  = todVec(getTod());
    sunW  = sunDirW();
    moonW = moonDirW();
    gl_Position = ftransform();
}
