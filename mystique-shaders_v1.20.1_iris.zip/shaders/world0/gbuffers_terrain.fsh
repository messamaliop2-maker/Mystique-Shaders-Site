#version 330 compatibility
#include "/lib/common.glsl"
#ifdef SHADOWS
#include "/lib/shadow_frag.glsl"
#endif

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normalV;
ENV_IN
#ifdef SHADOWS
in vec3 shadowCoord;
in float viewDist;
#endif

/* RENDERTARGETS: 0 */

void main() {
    vec4 c = texture(gtexture, texcoord);
    if (c.a < 0.1) discard;
    c.rgb *= glcolor.rgb;
    vec3 N = normalize(normalV);

    float sh = 1.0;
#ifdef SHADOWS
    sh = shadowFor(shadowCoord, viewDist, dot(N, envL));
#endif
    gl_FragData[0] = vec4(SHADE(c.rgb, lmcoord, N, sh), c.a);
}
