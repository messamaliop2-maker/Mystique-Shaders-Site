#version 330 compatibility
#include "/lib/common.glsl"

out vec2 texcoord;
flat out vec4 todV;
flat out vec3 sunW;

void main() {
    texcoord = gl_MultiTexCoord0.xy;
    todV = todVec(getTod());
    sunW = sunDirW();
    gl_Position = ftransform();
}
