#version 330 compatibility
#include "/lib/common.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */

void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (c.a < 0.02) discard;
    Tod t = getTod();
    c.rgb *= mix(vec3(1.0), vec3(0.55, 0.62, 0.80), t.night) * vec3(0.85, 0.92, 1.0);
    gl_FragData[0] = c;
}
