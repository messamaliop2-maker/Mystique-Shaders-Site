#version 330 compatibility
#include "/lib/common.glsl"

uniform sampler2D gtexture;
uniform float far;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normalV;
in vec3 normalW;
in vec3 worldPos;
in vec3 relPos;
flat in int isWater;
flat in vec4 todV;
flat in vec3 sunW;
flat in vec3 moonW;
ENV_IN

/* RENDERTARGETS: 0 */

void main() {
    vec4 tex = texture(gtexture, texcoord);

    // stained glass, ice, slime ... : lit like everything else
    if (isWater == 0) {
        vec4 c = tex * glcolor;
        if (c.a < 0.02) discard;
        gl_FragData[0] = vec4(SHADE(c.rgb, lmcoord, normalize(normalV), 1.0), c.a);
        return;
    }

    Tod t = makeTod(todV);
    float lmy = clamp((lmcoord.y - 0.0313) / 0.9375, 0.0, 1.0);
    float lmx = clamp((lmcoord.x - 0.0313) / 0.9375, 0.0, 1.0);
    vec3 V = normalize(relPos);                    // camera -> surface (world)

    vec3 Nw = normalize(normalW);
#if WATER_QUALITY > 0
    if (Nw.y > 0.5) {
        float tm = frameTimeCounter;
        vec2 a = worldPos.xz * 0.9 + vec2(tm * 0.35, tm * 0.20);
        float h0 = ns(a);
        float hx = ns(a + vec2(0.1, 0.0));
        float hz = ns(a + vec2(0.0, 0.1));
    #if WATER_QUALITY > 1
        vec2 b = worldPos.xz * 2.3 - vec2(tm * 0.50, tm * 0.30);
        h0 += 0.5 * ns(b);
        hx += 0.5 * ns(b + vec2(0.1, 0.0));
        hz += 0.5 * ns(b + vec2(0.0, 0.1));
    #endif
        Nw = normalize(vec3(-(hx - h0) * 1.1, 1.0, -(hz - h0) * 1.1));
    }
#endif

    float cosT = clamp(dot(-V, Nw), 0.0, 1.0);
    float ic = 1.0 - cosT;
    float fres = ic * ic * ic * 0.85 + 0.05;

    // body colour (original: day teal / night dark blue / crimson tint at sunset)
    vec3 body = vec3(0.08, 0.50, 0.62) * t.day
              + vec3(0.14, 0.34, 0.48) * t.sunset
              + vec3(0.02, 0.08, 0.20) * t.night;
    body += vec3(0.15, 0.02, 0.0) * t.sunset;
    body *= 0.85 + 0.35 * dot(tex.rgb, vec3(0.333));
    float light = mix(0.30, 1.0, lmy);
    body *= mix(light, 0.55 + 0.45 * light, t.rain);
    body += vec3(1.2, 0.5, 0.1) * (lmx * lmx * lmx * 0.30 * (1.0 - lmy * 0.7));

    // sky reflection
    vec3 R = reflect(V, Nw);
    R.y = abs(R.y);
    vec3 refl = skyGradient(R, t, sunW, moonW) * mix(0.25, 1.0, lmy);

    // sun / moon glints (the original "sun reflect" streaks)
    vec3 Ls = mix(sunW, moonW, t.night);
    float rd = max(dot(R, Ls), 0.0);
    float spec = pow(rd, 200.0) * 3.0 + pow(rd, 14.0) * 0.35;
    vec3 specCol = mix(vec3(1.0, 0.9, 0.7), vec3(1.6, 0.45, 0.12), t.sunset);
    specCol = mix(specCol, vec3(0.18, 0.24, 0.40), t.night);
    spec *= lmy * (1.0 - t.rain);

    vec3 col = mix(body, refl, clamp(fres * WATER_REFLECT, 0.0, 1.0)) + specCol * spec;
    col = filmicRGB(col);
    if (t.rain > 0.001) col = saturation(col, 1.0 - 0.5 * t.rain);

    float alpha = clamp(0.58 + 0.38 * fres + length(relPos) / max(far, 1.0) * 0.5, 0.0, 0.97);
    gl_FragData[0] = vec4(col, alpha);
}
