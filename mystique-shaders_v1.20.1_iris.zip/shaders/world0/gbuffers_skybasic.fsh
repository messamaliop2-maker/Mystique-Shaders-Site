#version 330 compatibility
#include "/lib/common.glsl"

uniform int renderStage;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 gbufferProjectionInverse;

in vec4 glcolor;
in vec3 starPos;
flat in vec4 todV;
flat in vec3 sunW;
flat in vec3 moonW;

/* RENDERTARGETS: 0 */

void main() {
    if (renderStage == MC_RENDER_STAGE_SUNSET || renderStage == MC_RENDER_STAGE_VOID) discard;

    Tod t = makeTod(todV);

    if (renderStage == MC_RENDER_STAGE_STARS) {
        float tw = 0.70 + 0.30 * sin(frameTimeCounter * 3.0 + dot(starPos, vec3(91.7, 57.3, 33.1)));
        vec3 tint = vec3(0.80, 0.88, 1.0)
                  + 0.20 * vec3(sin(starPos.x * 70.0 + frameTimeCounter * 0.7),
                                sin(starPos.z * 61.0 + frameTimeCounter * 0.9), 0.0);
        float a = glcolor.a * clamp(t.night * 1.2, 0.0, 1.0) * (1.0 - t.rain);
        if (a < 0.01) discard;
        gl_FragData[0] = vec4(tint * (tw * STAR_BRIGHTNESS * 1.6), a);
        return;
    }

    vec3 ndc = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * vec4(ndc, 1.0);
    vec3 dW = mat3(gbufferModelViewInverse) * normalize(v.xyz / v.w);
    gl_FragData[0] = vec4(skyGradient(dW, t, sunW, moonW), 1.0);
}
